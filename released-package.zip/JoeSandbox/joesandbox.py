from time import sleep

import requests
from os import environ
from jbxapi import ConnectionError, InvalidApiKeyError, InvalidParameterError
from jbxapi import JoeSandbox as JoeAPI
from jbxapi import PermissionError, ServerOfflineError
from .const import Joe_Config, RETRY_STATUS_CODE, SENTINEL_API


class JoeSandbox:
    """
    Wrapper class for JoeSandboxRESTAPI modules and functions.
    Import this class to submit samples and retrieve reports.from_time
    """

    def __init__(self, log):
        """
        Initialize, authenticate the JoeSandbox instance,
        use JoeSandboxConfig as configuration
        :param log: logger instance
        :return void
        """
        self.api = None
        self.log = log

        self.authenticate()

    def authenticate(self):
        """
        Authenticate and verify the JoeSandbox REST API connection.
        :raises: Various exceptions if connection or config is invalid.
        """
        try:
            self.api = JoeAPI(
                apiurl=Joe_Config.API_URL,
                apikey=Joe_Config.API_KEY,
                verify_ssl=True,
                user_agent=Joe_Config.CONNECTOR_NAME,
                accept_tac=True,
                retries=Joe_Config.RETRIES,
            )
            self.api.server_online()
            self.log.info(
                "Successfully authenticated and verified JoeSandbox API",
            )
        except InvalidApiKeyError as inerr:
            self.log.error("Invalid API key for JoeSandbox: %s", inerr)
            raise
        except PermissionError as perr:
            self.log.error("The user does not have the required permissions: %s", perr)
            raise
        except ConnectionError as cerr:
            self.log.error("Failed to connect to JoeSandbox server: %s", cerr)
            raise
        except ServerOfflineError as serr:
            self.log.error("Joe Sandbox is offline: %s", serr)
            raise
        except Exception as err:
            self.log.error("Unexpected error during JoeSandbox authentication: %s", err)
            raise


    def check_id(self, id_to_check: int | str) -> bool:
        """Checks if parameter id_to_check is a number

        Args:
            id_to_check (int or str):

        Returns:
            bool: True if is a number, else returns error
        """
        if (
            isinstance(id_to_check, int)
            or isinstance(id_to_check, str)
            and id_to_check.isdigit()
        ):
            return True
        raise ValueError(f"Invalid ID `{id_to_check}` provided.")

    def get_analysis(self, query: str) -> list | None:
        """
        Fetch the analysis associated based on a given query (hash or url) from JoeSandbox.

        Args:
            query (str): The SHA-256 hash of the file or url for which the analysis
            is being requested.

        Returns:
            list or None: A list of analysis metadata matching the hash value, or None
            if no analysis is available or the operation fails.
        """
        try:
            response = self.api.analysis_search(query)
            if response:
                self.log.info("Analysis for %s retrieved from JoeSandbox", query)
                return response
        except InvalidParameterError as inperr:
            self.log.error("An API parameter is invalid.. Error: %s", inperr)
        except ConnectionError as cerr:
            self.log.error("Failed to connect to JoeSandbox server.. Error: %s", cerr)
        except Exception as err:
            self.log.error(
                "Unexpected error while retrieving analysis for %s: %s", query, err
            )

        return None

    def download_analysis(self, web_id: str, download_type: str) -> tuple | None:
        """
        Download the analysis associated with web id from JoeSandbox.

        Args:
            web_id (str): web id of analysis
            download_type: the report type, e.g. 'html', 'bins', irjsonfixed

        Returns:
            list or None: A list of analysis metadata matching the hash value, or None
            if no analysis is available or the operation fails.
        """
        try:
            response = self.api.analysis_download(web_id, type=download_type)
            if response:
                self.log.info("Analysis for %s retrieved from JoeSandbox", web_id)
                return response
        except InvalidParameterError as inperr:
            self.log.error("An API parameter is invalid.. Error: %s", inperr)
        except ConnectionError as cerr:
            self.log.error("Failed to connect to JoeSandbox server.. Error: %s", cerr)
        except Exception as err:
            self.log.error(
                "Unexpected error while retrieving analysis for %s: %s", web_id, err
            )

        return None

    def get_analysis_info(self, web_id: str) -> dict | None:
        """
        Fetch the analysis associated with a particular web_id from JoeSandbox.

        Args:
            web_id (str): The web id of the analysis.
        Returns:
            dict or None: A dictionary containing the analysis result if found, or None
            if no analysis is available or the operation fails.
        """
        try:
            response = self.api.analysis_info(web_id)
            if response:
                self.log.info("Analysis retrieved from JoeSandbox")
                return response
        except InvalidParameterError as inperr:
            self.log.error("An API parameter is invalid... Error: %s", inperr)
        except ConnectionError as cerr:
            self.log.error(
                "Failed to connect to JoeSandbox server while fetching analysis info.. Error: %s",
                cerr,
            )
        except Exception as err:
            self.log.error("Unexpected error while retrieving analysis: %s", err)

        return None

    def get_submission(self, submission_id) -> dict|None:
        """
        Get submission details using submission id
        Args:
            submission_id: submission id
        Returns:
            Dict: Submission information
        """
        try:
            response = self.api.submission_info(submission_id)
            return response
        except InvalidParameterError as inperr:
            self.log.error("An API parameter is invalid... Error: %s", inperr)
        except ConnectionError as cerr:
            self.log.error(
                "Failed to connect to JoeSandbox server while fetching submission info.. Error: %s",
                cerr,
            )
        except Exception as err:
            self.log.error("Unexpected error while retrieving submission details: %s", err)

        return None


    def get_analysis_list(self, initial_fetch: str, detections: list):
        """
        Fetches a list of analyses from JoeSandbox filtered by detection type and after-date.

        Args:
            initial_fetch (str): The date string (e.g. "2024-01-01") to filter results after.
            detections (list): List of detection types (e.g. ["malicious", "suspicious"]).

        Returns:
            list: A list of analysis entries, or None in case of failure.
        """
        analysis_list = []

        for detection in detections:
            pagination_next = None

            while True:
                try:
                    payload = {
                        "apikey": Joe_Config.API_KEY,
                        "pagination": "1",
                        "after-date": initial_fetch,
                        "detection": detection
                    }

                    if pagination_next:
                        payload["pagination_next"] = pagination_next

                    response = requests.post(
                        url=f"{Joe_Config.API_URL}/v2/analysis/list",
                        data=payload
                    )

                    response.raise_for_status()
                    data = response.json()

                    analysis_list.extend(data.get("data", []))

                    pagination_next = data.get("pagination", {}).get("next")
                    if not pagination_next:
                        break

                except requests.HTTPError as http_err:
                    try:
                        error_msg = http_err.response.json().get("errors", [{}])[0].get("message", "Unknown HTTP error")
                    except Exception:
                        error_msg = str(http_err)
                    self.log.error(
                        f"HTTP error while fetching analysis list (status code {http_err.response.status_code}): {error_msg}"
                    )
                    return None

                except requests.ConnectionError as conn_err:
                    self.log.error(f"Connection error during analysis list fetch: {conn_err}")
                    return None

                except requests.RequestException as req_err:
                    self.log.error(f"Request error during analysis list fetch: {req_err}")
                    return None

                except Exception as err:
                    self.log.error(f"Unexpected error during analysis list fetch: {err}")
                    return None

        return analysis_list





