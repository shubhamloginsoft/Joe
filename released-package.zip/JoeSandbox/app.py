"""
Main Function
"""

# pylint: disable=logging-fstring-interpolation

import logging
from datetime import datetime, timedelta
from json import loads
from traceback import format_exc

import azure.functions as func

from .const import IOC_LIST, Joe_Config
from .utils import (
    IOC_MAPPING_FUNCTION,
    get_last_saved_timestamp,
    save_checkpoint,
    submit_indicator,
    joe_api, parse_analysis_data
)

def main(mytimer: func.TimerRequest) -> None:
    """
    Timer-triggered Azure Function to interact with the JoeSandbox API.

    This function fetches recent analyses from JoeSandbox, processes finished results,
    extracts IOCs, and submits them to Microsoft Sentinel. It handles pagination, API
    errors, and maintains state using checkpointing.

    Parameters
    ----------
    mytimer : func.TimerRequest
        Timer trigger object.
    """
    try:
        if mytimer.past_due:
            logging.info("The timer is past due!")
            return

        last_run = get_last_saved_timestamp()
        if last_run:
            logging.info(f"Last run timestamp: {last_run}")
        else:
            last_run = (datetime.now() - timedelta(days=int(Joe_Config.INITIAL_FETCH))).strftime("%Y-%m-%d")
            logging.info(f"No checkpoint found. Using initial fetch date: {last_run}")

        current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")

        verdicts = Joe_Config.JOE_ANALYSIS_VERDICTS.split(" & ")
        logging.info(f"Configured analysis verdicts: {verdicts}")

        analysis_list = joe_api.get_analysis_list(last_run, verdicts)

        for analysis in analysis_list:
            if analysis.get("status") != "finished":
                continue

            webid = analysis.get("webid")
            logging.info(f"Processing finished analysis: {webid}")

            _, file_data = joe_api.api.analysis_download(webid, "irjsonfixed")
            json_file_data = loads(file_data)

            analysis_info = joe_api.get_analysis_info(webid)

            iocs = parse_analysis_data(json_file_data)
            for key, values in iocs.items():
                if key in IOC_LIST and key in IOC_MAPPING_FUNCTION:
                    IOC_MAPPING_FUNCTION[key](values, analysis_info)

        submit_indicator()
        save_checkpoint(current_time)

    except Exception as ex:
        logging.error("An unexpected error occurred.")
        logging.error(f"Error: {ex}")
        logging.error(f"Traceback: {format_exc()}")

